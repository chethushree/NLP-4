# TopicLens Studio — START HERE

## Run in VS Code

Open this exact folder in VS Code, then Terminal:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app\app.py
```

If PowerShell blocks activation:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run app\app.py
```

The page works immediately using the built-in corpus. No external dataset download is required.

## Demonstration
1. Open TopicLens Studio.
2. Show corpus preparation and document-term matrix.
3. Use 4 topics.
4. Explain topic-word lists.
5. Show topic prevalence.
6. Click Run Gibbs Sampling.
7. Compare sampled topics with probabilistic LDA.
8. Use Document Explorer with `machine learning`, `energy`, `marketing`, or `health`.

## Custom data
- Upload TXT files: one file = one document.
- Upload CSV: select the text column.

## Academic mapping
Aim → preprocessing → document-term matrix → LDA → topic-word distributions → probabilistic/sampling comparison → interpretation → visualisation.
