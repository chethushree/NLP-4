Generated charts/results can be saved here during the experiment.
