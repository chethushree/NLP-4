# TopicLens Studio
## LDA Topic Discovery Web Application

A polished Streamlit implementation of the Latent Dirichlet Allocation experiment.

### Included
- Built-in reproducible document corpus
- TXT and CSV upload
- text preprocessing
- document-term matrix
- Scikit-learn LDA (Variational Bayes)
- custom collapsed Gibbs sampling
- topic-word distributions
- topic prevalence chart
- topic interpretation table
- document explorer
- professional Streamlit UI

See `START_HERE.md` for execution instructions.
