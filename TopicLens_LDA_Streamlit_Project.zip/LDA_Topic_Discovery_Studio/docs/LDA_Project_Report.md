# TopicLens Studio — LDA Topic Discovery Project Report

## 1. Aim
To apply Latent Dirichlet Allocation to a document collection and interpret the discovered topics using probabilistic and sampling-based methods.

## 2. Expected Outcomes
- Preprocess text data.
- Build a document-term representation.
- Train an LDA model.
- Interpret topic-word distributions.
- Compare probabilistic and sampling-based inference.
- Produce optional visualisations.

## 3. Methodology
Raw documents are normalized, tokenized and filtered using stop-word removal. A document-term matrix is built using CountVectorizer. Scikit-learn LDA provides a probabilistic variational-inference baseline. A custom collapsed Gibbs sampler provides the sampling-based method.

## 4. Topic Interpretation
A topic is interpreted by examining its highest-probability words and representative documents. Topic numbers have no inherent semantic meaning.

## 5. Application
TopicLens Studio is a Streamlit web interface with corpus upload, topic controls, topic-word tables, prevalence charts, Gibbs sampling, and document exploration.

## 6. Limitations
The bundled corpus is small and designed for education. Topic quality depends on corpus size, preprocessing, number of topics and inference settings.

## 7. Future Work
Use larger domain corpora, topic coherence metrics, interactive topic visualization, transformer embeddings, and automated topic labels.
