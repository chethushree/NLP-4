import re
import numpy as np
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt
from sklearn.feature_extraction.text import CountVectorizer, ENGLISH_STOP_WORDS
from sklearn.decomposition import LatentDirichletAllocation

st.set_page_config(page_title='TopicLens Studio', page_icon='🧭', layout='wide')
st.markdown('''<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Playfair+Display:wght@600;700&display=swap');
html,body,[class*="css"]{font-family:'DM Sans',sans-serif}.main .block-container{max-width:1280px;padding-top:1.4rem;padding-bottom:3rem}
.hero{padding:2.2rem 2.4rem;border-radius:28px;color:white;background:radial-gradient(circle at 85% 20%,#7c3aed 0,transparent 28%),radial-gradient(circle at 15% 100%,#0891b2 0,transparent 32%),linear-gradient(135deg,#111827,#1e1b4b 55%,#0f172a);box-shadow:0 20px 60px rgba(15,23,42,.18);margin-bottom:1.3rem}.hero h1{font-family:'Playfair Display',serif;font-size:3rem;margin:.1rem 0 .35rem}.hero p{color:#e0e7ff;font-size:1.03rem;max-width:850px;margin:0}.pill{display:inline-block;padding:.35rem .75rem;border-radius:999px;background:#ffffff18;border:1px solid #ffffff2e;font-size:.78rem;margin-bottom:.8rem}.card,.topic-card{border:1px solid #e5e7eb;border-radius:20px;padding:1.1rem 1.25rem;background:#fff;box-shadow:0 8px 25px rgba(15,23,42,.05)}.topic-card{margin-bottom:.7rem;background:linear-gradient(180deg,#fff,#f8fafc)}.topic-title{font-weight:700;font-size:1.05rem}.topic-words{color:#475569;line-height:1.7;margin-top:.35rem}.small{color:#64748b;font-size:.86rem}.metric{padding:1rem;border-radius:17px;background:#f8fafc;border:1px solid #e2e8f0}.answer{padding:1rem 1.15rem;border-left:4px solid #7c3aed;background:#faf5ff;border-radius:12px}.stButton>button{border-radius:12px;font-weight:600}
</style>''',unsafe_allow_html=True)

CORPUS={
'Technology':[
'Artificial intelligence systems learn patterns from data and support prediction classification and decision making. Machine learning models improve when training data is representative and carefully prepared.',
'Cloud computing provides scalable storage and computing resources. Distributed services allow applications to process large workloads without maintaining all infrastructure locally.',
'Cybersecurity protects networks software and information from unauthorized access. Threat detection authentication encryption and anomaly analysis are important security techniques.',
'Data science combines statistics programming and machine learning to discover useful patterns. Visualization and feature engineering help analysts understand complex datasets.',
'Natural language processing enables computers to analyze text language and meaning. Modern systems use embeddings transformers and language models for search and question answering.'],
'Environment':[
'Climate change affects temperature rainfall oceans and ecosystems. Renewable energy efficient transport and reduced emissions are important approaches to environmental sustainability.',
'Solar and wind power are renewable energy sources that can reduce dependence on fossil fuels. Energy storage helps manage variable renewable generation.',
'Forests support biodiversity carbon storage and water cycles. Conservation programs aim to protect habitats while supporting communities that depend on natural resources.',
'Air pollution contains particles and gases that can harm human health and ecosystems. Monitoring clean energy and better urban planning can reduce exposure.',
'Water resources are affected by drought pollution and changing rainfall patterns. Efficient irrigation recycling and watershed management improve long-term water security.'],
'Business':[
'Business strategy focuses on customers competition operations and sustainable growth. Companies use market research and performance metrics to make strategic decisions.',
'Marketing connects products with customers through branding communication and distribution. Digital platforms allow campaigns to be measured using engagement and conversion metrics.',
'Entrepreneurship involves identifying opportunities developing solutions and managing uncertainty. Startups often test ideas through prototypes and feedback from early users.',
'Financial management includes budgeting investment cash flow and risk analysis. Clear financial records help organizations plan and evaluate performance.',
'Supply chains coordinate suppliers manufacturing logistics and customers. Forecasting and inventory management can improve resilience and reduce operating costs.'],
'Health':[
'Public health programs focus on prevention healthy communities and access to essential services. Surveillance data can identify risks and guide interventions.',
'Nutrition provides energy and essential nutrients needed for growth and daily activity. Balanced diets commonly include vegetables fruits grains protein sources and healthy fats.',
'Exercise supports cardiovascular health strength and mobility. Regular physical activity can be incorporated through walking sports resistance training and active daily routines.',
'Medical research evaluates treatments through laboratory studies clinical trials and statistical analysis. Evidence quality is important when interpreting health claims.',
'Healthcare systems use electronic records analytics and decision support to improve coordination. Privacy and responsible handling of patient information are important considerations.']}
DOCS=[d for group in CORPUS.values() for d in group]; LABELS=[k for k,v in CORPUS.items() for _ in v]

def clean_text(t):
 t=re.sub(r'http\\S+|www\\S+',' ',str(t)); t=re.sub(r'[^A-Za-z\\s]',' ',t); return re.sub(r'\\s+',' ',t).strip().lower()
def tokenize(t): return [w for w in clean_text(t).split() if len(w)>2 and w not in ENGLISH_STOP_WORDS]

def gibbs_lda(docs,n_topics=4,iterations=150,alpha=.1,beta=.01,seed=42):
 rng=np.random.default_rng(seed); toks=[tokenize(d) for d in docs]; vocab=sorted(set(w for d in toks for w in d)); V=len(vocab); D=len(toks)
 if not V:return None
 wid={w:i for i,w in enumerate(vocab)}; z=[]; ndk=np.zeros((D,n_topics),int); nkw=np.zeros((n_topics,V),int); nk=np.zeros(n_topics,int)
 for d,words in enumerate(toks):
  zz=[]
  for w in words:
   k=int(rng.integers(n_topics)); zz.append(k); wi=wid[w]; ndk[d,k]+=1; nkw[k,wi]+=1; nk[k]+=1
  z.append(zz)
 for _ in range(iterations):
  for d,words in enumerate(toks):
   for i,w in enumerate(words):
    wi=wid[w]; old=z[d][i]; ndk[d,old]-=1; nkw[old,wi]-=1; nk[old]-=1
    p=(ndk[d]+alpha)*(nkw[:,wi]+beta)/(nk+V*beta); p=p/p.sum(); new=int(rng.choice(n_topics,p=p)); z[d][i]=new; ndk[d,new]+=1; nkw[new,wi]+=1; nk[new]+=1
 theta=ndk+alpha; theta/=theta.sum(axis=1,keepdims=True); phi=nkw+beta; phi/=phi.sum(axis=1,keepdims=True)
 return vocab,theta,phi

def top_words(phi,vocab,n): return [[vocab[i] for i in row.argsort()[-n:][::-1]] for row in phi]

with st.sidebar:
 st.markdown('## 🧭 TopicLens'); st.caption('LDA Topic Discovery Studio')
 source=st.radio('Corpus source',['Built-in demo corpus','Upload TXT files','Upload CSV'])
 n_topics=st.slider('Number of topics',2,8,4); top_n=st.slider('Top words per topic',5,15,10); seed=st.number_input('Random seed',0,9999,42)
 st.divider(); st.markdown('### Methods'); st.markdown('**LDA (Variational Bayes)**  \nScikit-learn implementation'); st.markdown('**LDA (Collapsed Gibbs)**  \nSampling-based implementation')

if source=='Upload TXT files':
 fs=st.file_uploader('Upload one or more .txt documents',type=['txt'],accept_multiple_files=True)
 if fs: docs=[f.read().decode('utf-8',errors='ignore') for f in fs]; labels=[f.name for f in fs]
 else: docs,labels=DOCS,LABELS
elif source=='Upload CSV':
 f=st.file_uploader('Upload CSV containing a text column',type=['csv'])
 if f:
  df=pd.read_csv(f); cols=[c for c in df.columns if df[c].dtype=='object']; col=st.selectbox('Select text column',cols); docs=df[col].fillna('').astype(str).tolist(); labels=[f'Document {i+1}' for i in range(len(docs))]
 else: docs,labels=DOCS,LABELS
else: docs,labels=DOCS,LABELS

st.markdown('''<div class="hero"><div class="pill">NLP • PROBABILISTIC TOPIC MODELING • LDA</div><h1>TopicLens Studio</h1><p>Discover hidden themes in a document collection using Latent Dirichlet Allocation, compare probabilistic and sampling-based inference, and interpret topic–word distributions in a clean research workspace.</p></div>''',unsafe_allow_html=True)
cleaned=[clean_text(d) for d in docs]; tokens=[tokenize(d) for d in docs]; all_tokens=[w for t in tokens for w in t]; vocab=sorted(set(all_tokens))
cs=st.columns(4)
for c,val,label in zip(cs,[len(docs),len(all_tokens),len(vocab),n_topics],['Documents','Tokens','Vocabulary','Topics']): c.markdown(f'<div class="metric"><div style="font-size:1.45rem;font-weight:700">{val}</div><div class="small">{label}</div></div>',unsafe_allow_html=True)

st.markdown('### 1 · Corpus Preparation'); st.markdown('<div class="card"><b>Pipeline:</b> Raw text → normalization → punctuation removal → tokenization → stop-word filtering → document–term matrix</div>',unsafe_allow_html=True)
with st.expander('View preprocessed documents'): st.dataframe(pd.DataFrame({'Document':labels,'Clean text':cleaned}),use_container_width=True,hide_index=True)
vectorizer=CountVectorizer(stop_words='english',min_df=1,max_df=.98); X=vectorizer.fit_transform(cleaned); terms=vectorizer.get_feature_names_out()
st.markdown(f'### 2 · Document–Term Representation <span class="small">{X.shape[0]} documents × {X.shape[1]} terms</span>',unsafe_allow_html=True)
with st.expander('Preview document–term matrix'): st.dataframe(pd.DataFrame(X.toarray()[:10],columns=terms),use_container_width=True)

lda=LatentDirichletAllocation(n_components=n_topics,random_state=int(seed),learning_method='batch',max_iter=25); doc_topic=lda.fit_transform(X); topic_words=[]
for comp in lda.components_:
 inds=comp.argsort()[-top_n:][::-1]; topic_words.append([(terms[i],float(comp[i])) for i in inds])
st.markdown('### 3 · LDA Topic Discovery'); a,b=st.columns([1.2,.8]); a.markdown('<div class="card"><b>Probabilistic LDA</b><br><span class="small">Variational Bayes inference using Scikit-learn</span></div>',unsafe_allow_html=True); b.markdown(f'<div class="card"><b>Log-likelihood</b><br><span class="small">{lda.score(X):.2f}</span></div>',unsafe_allow_html=True)
cc=st.columns(2)
for i,words in enumerate(topic_words):
 with cc[i%2]: st.markdown(f'<div class="topic-card"><div class="topic-title">Topic {i+1}</div><div class="topic-words">{" · ".join(w for w,_ in words)}</div></div>',unsafe_allow_html=True)
st.markdown('### 4 · Topic–Word Distribution'); st.dataframe(pd.DataFrame({f'Topic {i+1}':[w for w,_ in topic_words[i]] for i in range(n_topics)}),use_container_width=True,hide_index=True)
st.markdown('### 5 · Topic Prevalence'); prevalence=doc_topic.mean(axis=0); fig,ax=plt.subplots(figsize=(10,3.6)); ax.bar([f'Topic {i+1}' for i in range(n_topics)],prevalence); ax.set_ylabel('Average document-topic probability'); ax.set_xlabel('Topic'); ax.set_title('Average Topic Prevalence'); ax.grid(axis='y',alpha=.18); st.pyplot(fig,use_container_width=True); plt.close(fig)

st.markdown('### 6 · Sampling-Based LDA'); st.caption('Collapsed Gibbs sampling demonstrates the sampling-based inference method alongside probabilistic variational inference.')
if st.button('Run Gibbs Sampling',type='secondary'):
 with st.spinner('Running collapsed Gibbs sampling...'): result=gibbs_lda(docs,n_topics=n_topics,iterations=180,seed=int(seed))
 if result: st.session_state['gibbs']=(top_words(result[2],result[0],top_n),result[1]); st.success('Gibbs sampling completed.')
if 'gibbs' in st.session_state:
 tw2,_=st.session_state['gibbs']; cc=st.columns(2)
 for i,ws in enumerate(tw2):
  with cc[i%2]: st.markdown(f'<div class="topic-card"><div class="topic-title">Sampled Topic {i+1}</div><div class="topic-words">{" · ".join(ws)}</div></div>',unsafe_allow_html=True)

st.markdown('### 7 · Topic Interpretation'); st.dataframe(pd.DataFrame([{'Topic':f'Topic {i+1}','Top words':', '.join(w for w,_ in topic_words[i]),'Suggested interpretation':' / '.join(w for w,_ in topic_words[i][:4])} for i in range(n_topics)]),use_container_width=True,hide_index=True)
st.markdown('### 8 · Document Explorer'); q=st.text_input('Enter a word or phrase to inspect topic association',placeholder='Example: machine learning')
if q:
 qwords=tokenize(q); matched=[i for i,t in enumerate(tokens) if any(w in t for w in qwords)]
 if matched:
  st.dataframe(pd.DataFrame([{'Document':labels[i],'Dominant topic':f'Topic {int(np.argmax(doc_topic[i]))+1}','Probability':round(float(doc_topic[i].max()),3)} for i in matched[:20]]),use_container_width=True,hide_index=True)
 else: st.info('No matching documents found in the current corpus.')
st.markdown('### 9 · Interpretation Notes'); st.markdown('<div class="card"><b>How to read a topic:</b> LDA assigns each document a mixture of topics and each topic a probability distribution over words. High-probability words are more characteristic of that topic.<br><br><b>Important:</b> Topic numbers have no fixed semantic meaning. Interpretation should use top words and representative documents.</div>',unsafe_allow_html=True)
st.divider(); st.caption('TopicLens Studio · LDA Topic Discovery · Educational NLP Project')
